## 🧭 Coach Actions

{{#each actions}}
- {{this}}
{{/each}}
