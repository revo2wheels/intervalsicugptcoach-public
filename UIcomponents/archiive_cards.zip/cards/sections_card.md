## ⚙️ Training Sections

**Load Distribution**  
Z1–Z2 = {{z1_z2_pct}} % Z3–Z4 = {{z3_z4_pct}} % Z5+ = {{z5_pct}} %  
→ {{polarisation_comment}}

**Intensity & Recovery**  
ATL = {{atl}} CTL = {{ctl}} TSB = {{tsb}}  
→ {{fatigue_status}} ({{recovery_comment}})

**Load Quality Indicators**
| Metric | Value | Comment |
|:--|--:|:--|
| Monotony | {{monotony}} | {{monotony_comment}} |
| Strain | {{strain}} | {{strain_comment}} |
| Polarisation | {{polarisation}} | {{polarisation_comment}} |
| Recovery Index | {{recovery_index}} | {{recovery_comment}} |

**Interpretation**  
Weekly load distribution supports aerobic balance.  
Maintain ≥70 % Z1–Z2 work for optimal endurance development.
