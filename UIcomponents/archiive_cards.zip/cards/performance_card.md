## 🚀 Performance Readiness

| Metric | Current | 7d Trend |
|:--|--:|--:|
| CTL | {{ctl}} | {{ctl_trend}} |
| ATL | {{atl}} | {{atl_trend}} |
| TSB | {{tsb}} | {{tsb_trend}} |
| Fatigue Status | {{fatigue_status}} | — |

**Interpretation**  
TSB near 0 → optimal load balance.  
Readiness Index = {{readiness_index}} → {{readiness_comment}}
