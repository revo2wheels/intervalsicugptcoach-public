## ⚙️ Efficiency Trends

| Metric | Week Avg | Change vs Last |
|:--|--:|--:|
| Efficiency Factor (EF) | {{ef_avg}} | {{ef_change}} % |
| Decoupling | {{decoupling_avg}} % | {{decoupling_change}} % |
| Power:HR | {{power_hr_ratio}} | {{power_hr_trend}} |
| Cadence | {{cadence_avg}} rpm | {{cadence_trend}} |

Comment: {{efficiency_comment}}
