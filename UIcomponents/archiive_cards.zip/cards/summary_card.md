## 🧩 Weekly Summary

{{weekly_summary}}

**Highlights**
- Training Load = {{total_tss}} TSS
- Average Intensity = {{mean_if}}
- Recovery Status = {{recovery_comment}}
- Polarisation = {{polarisation_comment}}

✅ Audit Final = {{audit_final}} → Renderer Released
