## 🧮 Derived Metrics

| Metric | Value | Interpretation |
|:--|--:|:--|
| ACWR | {{acwr}} | {{acwr_comment}} |
| Monotony | {{monotony}} | {{monotony_comment}} |
| Strain | {{strain}} | {{strain_comment}} |
| Polarisation | {{polarisation}} | {{polarisation_comment}} |
| Fat Oxidation | {{fat_oxidation}} | {{fatox_comment}} |
| Decoupling | {{decoupling}} % | {{decoupling_comment}} |
