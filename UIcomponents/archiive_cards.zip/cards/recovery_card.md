## 💤 Recovery & Wellness

| Metric | Value | Trend |
|:--|--:|:--|
| Sleep (h) | {{sleep_avg}} | {{sleep_trend}} |
| HRV (ms) | {{hrv_avg}} | {{hrv_trend}} |
| Resting HR | {{rhr_avg}} | {{rhr_trend}} |
| Soreness | {{soreness_avg}} | {{soreness_comment}} |
| Stress | {{stress_avg}} | {{stress_comment}} |

Recovery Index = {{recovery_index}} → {{recovery_comment}}
