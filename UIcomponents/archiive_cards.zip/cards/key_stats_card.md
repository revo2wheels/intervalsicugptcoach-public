## 📈 Key Stats

| Metric | Value |
|:--|--:|
| Total Distance | {{total_distance}} km |
| Total Time | {{total_hours}} h |
| Total TSS | {{total_tss}} |
| Mean IF | {{mean_if}} |
| CTL / ATL / TSB | {{ctl}} / {{atl}} / {{tsb}} |
| ACWR | {{acwr}} |
| Polarisation | {{polarisation}} |
| Monotony | {{monotony}} |
| Strain | {{strain}} |
| Recovery Index | {{recovery_index}} |
