"""
report_validator.py — v16.1
Validates rendered reports against Unified Reporting Framework v5.1.
Ensures all output metrics, sections, and formatting meet canonical spec.
"""

import math

def validate_report_output(context, report, framework_version="Unified_Reporting_Framework_v5.1"):
    """
    Perform structural and logical validation of a rendered report.
    """

    # --- Framework verification ---
    if framework_version != "Unified_Reporting_Framework_v5.1":
        raise ValueError(f"❌ Invalid framework version: {framework_version}")

    # --- Renderer gate ---
    if not context.get("auditFinal", False):
        raise RuntimeError("❌ Renderer blocked: auditFinal=False")

    # --- Required context keys ---
    required_keys = ["totalHours", "totalTss", "actions", "athlete", "timezone"]
    missing = [k for k in required_keys if k not in context]
    if missing:
        raise KeyError(f"❌ Missing context keys: {missing}")

    # --- Type and range validation ---
    if not isinstance(context["totalHours"], (int, float)):
        raise TypeError("❌ totalHours must be numeric")
    if not isinstance(context["totalTss"], (int, float)):
        raise TypeError("❌ totalTss must be numeric")
    if context["totalHours"] < 0 or context["totalTss"] < 0:
        raise ValueError("❌ Negative totals detected")

    # --- Rounding and format checks ---
    rounded_hours = round(context["totalHours"], 2)
    if not math.isclose(context["totalHours"], rounded_hours, abs_tol=0.01):
        raise ValueError("❌ totalHours not rounded to 2 decimals")

    if not isinstance(context["actions"], list):
        raise TypeError("❌ actions must be a list")

    # --- Report structural validation ---
    required_sections = ["header","summary","metrics","actions","footer","phases","trends","correlation"]
    for section in required_sections:
        if section not in report:
            raise ValueError(f"❌ Missing report section: {section}")

    # --- Framework icon + label check ---
    icon_fields = ["🛌 Rest Day", "⏳ Current Day"]
    for icon in icon_fields:
        if icon not in report["summary"]:
            raise ValueError(f"❌ Framework icon missing: {icon}")

    # --- Variance and integrity ---
    variance_limit = 0.03  # 3%
    if "variance" in context and context["variance"] > variance_limit:
        raise ValueError(f"❌ Variance exceeds {variance_limit*100:.0f}% limit")

    # --- Metrics validation ---
    derived_metrics = ["ACWR", "Monotony", "Strain", "Polarisation", "RecoveryIndex"]
    for m in derived_metrics:
        if m not in context:
            raise ValueError(f"❌ Derived metric missing: {m}")
        val = context[m]
        if not isinstance(val, (int, float)) or math.isnan(val):
            raise TypeError(f"❌ Derived metric {m} invalid")

    # --- Render compliance summary ---
    compliance_log = {
        "framework": framework_version,
        "report_type": report.get("type", "unknown"),
        "auditFinal": context["auditFinal"],
        "checked_sections": required_sections,
        "verified_metrics": derived_metrics,
        "variance_ok": context.get("variance", 0) <= variance_limit,
        "icons_verified": True,
    }

    print("✅ Report validated — framework compliant.")
    return compliance_log
